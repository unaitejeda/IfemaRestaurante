<?php

define("url","http://localhost");
define("action_default","index");
